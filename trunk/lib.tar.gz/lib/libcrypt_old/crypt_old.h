#ifdef CONFIG_USER_OLD_PASSWORDS
extern char *crypt_old(const char *__key, const char *__salt);
#endif

