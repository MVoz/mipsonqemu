#ifndef K_INTERF_H
#define K_INTERF_H

int send_to_kernel( struct k_message *msg);
int msg_from_kernel(int fd);


#endif /* K_INTERF_H */





