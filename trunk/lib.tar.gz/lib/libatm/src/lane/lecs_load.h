/*
 *
 * LECS configuration database loading
 *
 * $Id: lecs_load.h,v 1.2 2001/10/09 22:33:07 paulsch Exp $
 *
 */
#ifndef LECS_LOAD_H
#define LECS_LOAD_H

int load_db(const char *filename);

#endif
