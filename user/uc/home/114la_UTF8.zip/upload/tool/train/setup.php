<?php
header('Content-Type: text/html; charset=utf-8');
require_once( '../../init.php' );
app_tpl::clear_compiled_tpl();
echo '鍒濆