<?php
$menu['列车时刻查询'] = array( 
    '基本设置' => '?c=plugin&p=train&do=cfg&np=插件管理,列车时刻查询,基本设置',
);
?>
