<?die;?>|admin|c=login&a=login?c=login&a=login|192.168.56.1|1260434760|login=array(name=admin, password=***, )|
<?die;?>|admin|c=login&a=header?c=login&a=header|192.168.56.1|1260434760||
<?die;?>|admin|c=login&a=welcome?c=login&a=welcome|192.168.56.1|1260434760||
<?die;?>|admin|c=login&a=menu?c=login&a=menu|192.168.56.1|1260434760||
<?die;?>|admin|c=update&t?c=update&t|192.168.56.1|1260434760||
<?die;?>|admin|c=login&a=menu?c=login&a=menu|192.168.56.1|1260434775||
<?die;?>|admin|c=login&a=login?c=login&a=login|192.168.56.1|1260434786|login=array(name=admin, password=***, )|
<?die;?>|admin|c=login&a=header?c=login&a=header|192.168.56.1|1260434786||
<?die;?>|admin|c=login&a=welcome?c=login&a=welcome|192.168.56.1|1260434786||
<?die;?>|admin|c=login&a=menu?c=login&a=menu|192.168.56.1|1260434786||
<?die;?>|admin|c=update&t?c=update&t|192.168.56.1|1260434787||
