<?php
!defined('PATH_ADMIN') && exit('Forbidden');

$zhuantidb = array(
    'game'=>'网络游戏',
    'game1'=>'单机游戏',
	'tool'=>'实用工具',
)
?>
