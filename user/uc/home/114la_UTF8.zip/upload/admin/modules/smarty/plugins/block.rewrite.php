<?php
!defined('PATH_ADMIN') && exit('Forbidden');
/**
 * URL Rewrite
 * @author skey <cookphp@gmail>
 * @version 1.0
 */
function smarty_block_rewrite($params, $content, &$smarty)
{
   return $content;
}
?>
