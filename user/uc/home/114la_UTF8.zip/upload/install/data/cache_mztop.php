a:5:{i:0;a:4:{s:4:"name";s:6:"百度";s:4:"html";s:576:"<li><a href="http://www.baidu.com/index.php?tn=ylmf_4_pg">百度</a>--<a href="http://mp3.ylmf.com/">Mp3</a> <em class="baid"></em>
<div class="fmbox">
<div class="arrow">百度</div>
<ul>
<li><a href="http://zhidao.baidu.com/q?pt=ylmf_ik">百度知道</a></li>
<li><a href="http://video.baidu.com/?tn=lqowen_1_pg">百度视频</a></li>
<li><a href="http://tieba.baidu.com/?source=114la.com">百度贴吧</a></li>
<li><a href="http://baike.baidu.com/?source=114la.com">百度百科</a></li>
<li><a href="http://hi.baidu.com">百度空间</a></li>
</ul>
</div>
</li>";s:5:"order";s:1:"1";s:4:"show";s:1:"1";}i:1;a:4:{s:4:"name";s:6:"新浪";s:4:"html";s:823:"<li><a href="http://www.sina.com.cn/">新浪</a>--<a href="http://news.sina.com.cn/">新闻</a> <em class="sina"></em>
<div class="fmbox"> <span class="arrow">新浪</span>
<ul>
<li><a href="http://finance.sina.com.cn">新浪财经</a></li>
<li><a href="http://sports.sina.com.cn">新浪体育</a></li>
<li><a href="http://blog.sina.com.cn">新浪博客</a></li>
<li><a href="http://sina.allyes.com/main/adfclick?db=sina&bid=155888,196233,201227&cid=0,0,0&sid=189148&advid=3406&camid=27233&show=ignore&url=http://auto.sina.com.cn/?c=spr_web_sq_114la_auto">新浪汽车</a></li>
<li><a href="http://sina.allyes.com/main/adfclick?db=sina&bid=164211,206178,211190&cid=0,0,0&sid=199245&advid=3406&camid=29028&show=ignore&url=http://video.sina.com.cn/?c=spr_web_sq_114la_video">新浪宽频</a></li>
</ul>
</div>
</li>";s:5:"order";s:1:"2";s:4:"show";s:1:"1";}i:2;a:4:{s:4:"name";s:6:"搜狐";s:4:"html";s:487:"<li><a href="http://www.sohu.com/">搜狐</a>--<a href="http://news.sohu.com/">新闻</a> <em class="sohu"></em>
<div class="fmbox"> <span class="arrow">搜狐</span>
<ul>
<li><a href="http://blog.sohu.com">搜狐博客</a></li>
<li><a href="http://business.sohu.com">搜狐财经</a></li>
<li><a href="http://auto.sohu.com">搜狐汽车</a></li>
<li><a href="http://it.sohu.com">搜狐科技</a></li>
<li><a href="http://club.sohu.com">搜狐社区</a></li>
</ul>
</div>
</li>";s:5:"order";s:1:"3";s:4:"show";s:1:"1";}i:3;a:4:{s:4:"name";s:6:"网易";s:4:"html";s:479:"<li><a href="http://www.163.com/">网易</a>--<a href="http://news.163.com/">新闻</a> <em class="wy"></em>
<div class="fmbox"> <span class="arrow">网易</span>
<ul>
<li><a href="http://news.163.com">网易新闻</a></li>
<li><a href="http://money.163.com">网易财经</a></li>
<li><a href="http://blog.163.com">网易博客</a></li>
<li><a href="http://photo.163.com">网易相册</a></li>
<li><a href="http://tech.163.com/">网易科技</a></li>
</ul>
</div>
</li>";s:5:"order";s:1:"4";s:4:"show";s:1:"1";}i:4;a:4:{s:4:"name";s:6:"腾讯";s:4:"html";s:474:"<li><a href="http://www.qq.com/">腾讯</a>--<a href="http://tech.qq.com/">科技</a> <em class="qq"></em>
<div class="fmbox"> <span class="arrow">腾讯</span>
<ul>
<li><a href="http://news.qq.com/">腾讯新闻</a></li>
<li><a href="http://finance.qq.com">腾讯财经</a></li>
<li><a href="http://ent.qq.com">腾讯娱乐</a></li>
<li><a href="http://auto.qq.com">腾讯汽车</a></li>
<li><a href="http://games.qq.com/">腾讯游戏</a></li>
</ul>
</div>
</li>";s:5:"order";s:1:"6";s:4:"show";s:1:"1";}}